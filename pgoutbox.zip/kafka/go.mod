module github.com/WlcM111/pgoutbox/kafka

go 1.26.6

require github.com/segmentio/kafka-go v0.4.49

require (
	github.com/klauspost/compress v1.15.9 // indirect
	github.com/pierrec/lz4/v4 v4.1.15 // indirect
)
